namespace LibreLancer.Thn;

public enum ThnAxis
{
    XAxis = 0,
    YAxis = 1,
    ZAxis = 2,
    NegXAxis = 3,
    NegYAxis = 4,
    NegZAxis = 5
}
